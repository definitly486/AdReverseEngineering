package com.applovin.shadow.okhttp3.internal.http;

import com.applovin.shadow.okhttp3.Interceptor;
import com.applovin.shadow.okhttp3.Request;
import com.applovin.shadow.okhttp3.RequestBody;
import com.applovin.shadow.okhttp3.Response;
import com.applovin.shadow.okhttp3.ResponseBody;
import com.applovin.shadow.okhttp3.internal.Util;
import com.applovin.shadow.okhttp3.internal.connection.Exchange;
import com.applovin.shadow.okhttp3.internal.http2.ConnectionShutdownException;
import com.applovin.shadow.okio.BufferedSink;
import com.applovin.shadow.okio.Okio;
import defpackage.pe1;
import io.content.protobuf.sdk.MaskedSignals;
import java.io.IOException;
import java.net.ProtocolException;
import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-88e60a0b00c44f446761c69dbdea1ba6dba6b1d88516f4344ee4a32f493f3b32 */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0010\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0016J\u0010\u0010\t\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\u000bH\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\f"}, d2 = {"Lcom/applovin/shadow/okhttp3/internal/http/CallServerInterceptor;", "Lcom/applovin/shadow/okhttp3/Interceptor;", "forWebSocket", "", "(Z)V", "intercept", "Lcom/applovin/shadow/okhttp3/Response;", "chain", "Lcom/applovin/shadow/okhttp3/Interceptor$Chain;", "shouldIgnoreAndWaitForRealResponse", "code", "", "okhttp"}, k = 1, mv = {1, 8, 0}, xi = MaskedSignals.LASTBOOTUP_HISTORY_FIELD_NUMBER)
public final class CallServerInterceptor implements Interceptor {
    private final boolean forWebSocket;

    public CallServerInterceptor(boolean z) {
        this.forWebSocket = z;
    }

    private final boolean shouldIgnoreAndWaitForRealResponse(int code) {
        if (code == 100) {
            return true;
        }
        return 102 <= code && code < 200;
    }

    /* JADX WARN: Code duplicated, block: B:41:0x00b1 A[Catch: IOException -> 0x0199, TryCatch #0 {IOException -> 0x0199, blocks: (B:39:0x00a8, B:41:0x00b1, B:42:0x00b5, B:44:0x00df, B:46:0x00e8, B:47:0x00eb, B:48:0x010f, B:52:0x011a, B:54:0x0139, B:56:0x0147, B:63:0x015d, B:65:0x0163, B:69:0x0170, B:71:0x0185, B:72:0x018d, B:73:0x0197, B:58:0x0152, B:53:0x0129), top: B:82:0x00a8 }] */
    /* JADX WARN: Code duplicated, block: B:44:0x00df A[Catch: IOException -> 0x0199, TryCatch #0 {IOException -> 0x0199, blocks: (B:39:0x00a8, B:41:0x00b1, B:42:0x00b5, B:44:0x00df, B:46:0x00e8, B:47:0x00eb, B:48:0x010f, B:52:0x011a, B:54:0x0139, B:56:0x0147, B:63:0x015d, B:65:0x0163, B:69:0x0170, B:71:0x0185, B:72:0x018d, B:73:0x0197, B:58:0x0152, B:53:0x0129), top: B:82:0x00a8 }] */
    /* JADX WARN: Code duplicated, block: B:46:0x00e8 A[Catch: IOException -> 0x0199, TryCatch #0 {IOException -> 0x0199, blocks: (B:39:0x00a8, B:41:0x00b1, B:42:0x00b5, B:44:0x00df, B:46:0x00e8, B:47:0x00eb, B:48:0x010f, B:52:0x011a, B:54:0x0139, B:56:0x0147, B:63:0x015d, B:65:0x0163, B:69:0x0170, B:71:0x0185, B:72:0x018d, B:73:0x0197, B:58:0x0152, B:53:0x0129), top: B:82:0x00a8 }] */
    /* JADX WARN: Code duplicated, block: B:53:0x0129 A[Catch: IOException -> 0x0199, TryCatch #0 {IOException -> 0x0199, blocks: (B:39:0x00a8, B:41:0x00b1, B:42:0x00b5, B:44:0x00df, B:46:0x00e8, B:47:0x00eb, B:48:0x010f, B:52:0x011a, B:54:0x0139, B:56:0x0147, B:63:0x015d, B:65:0x0163, B:69:0x0170, B:71:0x0185, B:72:0x018d, B:73:0x0197, B:58:0x0152, B:53:0x0129), top: B:82:0x00a8 }] */
    /* JADX WARN: Code duplicated, block: B:58:0x0152 A[Catch: IOException -> 0x0199, TryCatch #0 {IOException -> 0x0199, blocks: (B:39:0x00a8, B:41:0x00b1, B:42:0x00b5, B:44:0x00df, B:46:0x00e8, B:47:0x00eb, B:48:0x010f, B:52:0x011a, B:54:0x0139, B:56:0x0147, B:63:0x015d, B:65:0x0163, B:69:0x0170, B:71:0x0185, B:72:0x018d, B:73:0x0197, B:58:0x0152, B:53:0x0129), top: B:82:0x00a8 }] */
    /* JADX WARN: Code duplicated, block: B:63:0x015d A[Catch: IOException -> 0x0199, TryCatch #0 {IOException -> 0x0199, blocks: (B:39:0x00a8, B:41:0x00b1, B:42:0x00b5, B:44:0x00df, B:46:0x00e8, B:47:0x00eb, B:48:0x010f, B:52:0x011a, B:54:0x0139, B:56:0x0147, B:63:0x015d, B:65:0x0163, B:69:0x0170, B:71:0x0185, B:72:0x018d, B:73:0x0197, B:58:0x0152, B:53:0x0129), top: B:82:0x00a8 }] */
    /* JADX WARN: Code duplicated, block: B:65:0x0163 A[Catch: IOException -> 0x0199, TryCatch #0 {IOException -> 0x0199, blocks: (B:39:0x00a8, B:41:0x00b1, B:42:0x00b5, B:44:0x00df, B:46:0x00e8, B:47:0x00eb, B:48:0x010f, B:52:0x011a, B:54:0x0139, B:56:0x0147, B:63:0x015d, B:65:0x0163, B:69:0x0170, B:71:0x0185, B:72:0x018d, B:73:0x0197, B:58:0x0152, B:53:0x0129), top: B:82:0x00a8 }] */
    /* JADX WARN: Code duplicated, block: B:66:0x0168  */
    /* JADX WARN: Code duplicated, block: B:69:0x0170 A[Catch: IOException -> 0x0199, TryCatch #0 {IOException -> 0x0199, blocks: (B:39:0x00a8, B:41:0x00b1, B:42:0x00b5, B:44:0x00df, B:46:0x00e8, B:47:0x00eb, B:48:0x010f, B:52:0x011a, B:54:0x0139, B:56:0x0147, B:63:0x015d, B:65:0x0163, B:69:0x0170, B:71:0x0185, B:72:0x018d, B:73:0x0197, B:58:0x0152, B:53:0x0129), top: B:82:0x00a8 }] */
    /* JADX WARN: Code duplicated, block: B:71:0x0185 A[Catch: IOException -> 0x0199, TryCatch #0 {IOException -> 0x0199, blocks: (B:39:0x00a8, B:41:0x00b1, B:42:0x00b5, B:44:0x00df, B:46:0x00e8, B:47:0x00eb, B:48:0x010f, B:52:0x011a, B:54:0x0139, B:56:0x0147, B:63:0x015d, B:65:0x0163, B:69:0x0170, B:71:0x0185, B:72:0x018d, B:73:0x0197, B:58:0x0152, B:53:0x0129), top: B:82:0x00a8 }] */
    /* JADX WARN: Code duplicated, block: B:82:0x00a8 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    @Override // com.applovin.shadow.okhttp3.Interceptor
    public Response intercept(Interceptor.Chain chain) throws IOException {
        Response.Builder responseHeaders;
        Response responseBuild;
        int iCode;
        Response responseBuild2;
        ResponseBody responseBodyBody;
        long contentLength;
        boolean z;
        chain.getClass();
        RealInterceptorChain realInterceptorChain = (RealInterceptorChain) chain;
        Exchange exchange = realInterceptorChain.getExchange();
        exchange.getClass();
        Request request = realInterceptorChain.getRequest();
        RequestBody requestBodyBody = request.body();
        long jCurrentTimeMillis = System.currentTimeMillis();
        boolean z2 = true;
        try {
            exchange.writeRequestHeaders(request);
            if (!HttpMethod.permitsRequestBody(request.method()) || requestBodyBody == null) {
                exchange.noRequestBody();
                responseHeaders = null;
            } else {
                if ("100-continue".equalsIgnoreCase(request.header("Expect"))) {
                    exchange.flushRequest();
                    responseHeaders = exchange.readResponseHeaders(true);
                    try {
                        exchange.responseHeadersStart();
                        z = false;
                    } catch (IOException e) {
                        e = e;
                        if ((e instanceof ConnectionShutdownException) || !exchange.getHasFailure()) {
                            throw e;
                        }
                        if (responseHeaders == null) {
                            try {
                                responseHeaders = exchange.readResponseHeaders(false);
                                responseHeaders.getClass();
                                if (z2) {
                                    exchange.responseHeadersStart();
                                    z2 = false;
                                }
                            } catch (IOException e2) {
                                if (e == null) {
                                    throw e2;
                                }
                                pe1.j(e, e2);
                                throw e;
                            }
                        }
                        responseBuild = responseHeaders.request(request).handshake(exchange.getConnection().getHandshake()).sentRequestAtMillis(jCurrentTimeMillis).receivedResponseAtMillis(System.currentTimeMillis()).build();
                        iCode = responseBuild.code();
                        if (shouldIgnoreAndWaitForRealResponse(iCode)) {
                            Response.Builder responseHeaders2 = exchange.readResponseHeaders(false);
                            responseHeaders2.getClass();
                            if (z2) {
                                exchange.responseHeadersStart();
                            }
                            responseBuild = responseHeaders2.request(request).handshake(exchange.getConnection().getHandshake()).sentRequestAtMillis(jCurrentTimeMillis).receivedResponseAtMillis(System.currentTimeMillis()).build();
                            iCode = responseBuild.code();
                        }
                        exchange.responseHeadersEnd(responseBuild);
                        if (this.forWebSocket) {
                            responseBuild2 = responseBuild.newBuilder().body(exchange.openResponseBody(responseBuild)).build();
                        } else {
                            responseBuild2 = responseBuild.newBuilder().body(exchange.openResponseBody(responseBuild)).build();
                        }
                        if ("close".equalsIgnoreCase(responseBuild2.request().header("Connection"))) {
                            exchange.noNewExchangesOnConnection();
                        } else {
                            exchange.noNewExchangesOnConnection();
                        }
                        if (iCode != 204) {
                            responseBodyBody = responseBuild2.body();
                            if (responseBodyBody != null) {
                                contentLength = responseBodyBody.getContentLength();
                            } else {
                                contentLength = -1;
                            }
                            if (contentLength > 0) {
                                StringBuilder sb = new StringBuilder("HTTP ");
                                sb.append(iCode);
                                sb.append(" had non-zero Content-Length: ");
                                ResponseBody responseBodyBody2 = responseBuild2.body();
                                sb.append(responseBodyBody2 != null ? Long.valueOf(responseBodyBody2.getContentLength()) : null);
                                throw new ProtocolException(sb.toString());
                            }
                        } else {
                            responseBodyBody = responseBuild2.body();
                            if (responseBodyBody != null) {
                                contentLength = responseBodyBody.getContentLength();
                            } else {
                                contentLength = -1;
                            }
                            if (contentLength > 0) {
                                StringBuilder sb2 = new StringBuilder("HTTP ");
                                sb2.append(iCode);
                                sb2.append(" had non-zero Content-Length: ");
                                ResponseBody responseBodyBody3 = responseBuild2.body();
                                sb2.append(responseBodyBody3 != null ? Long.valueOf(responseBodyBody3.getContentLength()) : null);
                                throw new ProtocolException(sb2.toString());
                            }
                        }
                        return responseBuild2;
                    }
                } else {
                    z = true;
                    responseHeaders = null;
                }
                try {
                    if (responseHeaders != null) {
                        exchange.noRequestBody();
                        if (!exchange.getConnection().isMultiplexed$okhttp()) {
                            exchange.noNewExchangesOnConnection();
                        }
                    } else if (requestBodyBody.isDuplex()) {
                        exchange.flushRequest();
                        requestBodyBody.writeTo(Okio.buffer(exchange.createRequestBody(request, true)));
                    } else {
                        BufferedSink bufferedSinkBuffer = Okio.buffer(exchange.createRequestBody(request, false));
                        requestBodyBody.writeTo(bufferedSinkBuffer);
                        bufferedSinkBuffer.close();
                    }
                    z2 = z;
                } catch (IOException e3) {
                    e = e3;
                    z2 = z;
                    if (e instanceof ConnectionShutdownException) {
                        throw e;
                    }
                    throw e;
                }
            }
            if (requestBodyBody == null || !requestBodyBody.isDuplex()) {
                exchange.finishRequest();
            }
            e = null;
        } catch (IOException e4) {
            e = e4;
            responseHeaders = null;
        }
        if (responseHeaders == null) {
            responseHeaders = exchange.readResponseHeaders(false);
            responseHeaders.getClass();
            if (z2) {
                exchange.responseHeadersStart();
                z2 = false;
            }
        }
        responseBuild = responseHeaders.request(request).handshake(exchange.getConnection().getHandshake()).sentRequestAtMillis(jCurrentTimeMillis).receivedResponseAtMillis(System.currentTimeMillis()).build();
        iCode = responseBuild.code();
        if (shouldIgnoreAndWaitForRealResponse(iCode)) {
            Response.Builder responseHeaders3 = exchange.readResponseHeaders(false);
            responseHeaders3.getClass();
            if (z2) {
                exchange.responseHeadersStart();
            }
            responseBuild = responseHeaders3.request(request).handshake(exchange.getConnection().getHandshake()).sentRequestAtMillis(jCurrentTimeMillis).receivedResponseAtMillis(System.currentTimeMillis()).build();
            iCode = responseBuild.code();
        }
        exchange.responseHeadersEnd(responseBuild);
        if (this.forWebSocket || iCode != 101) {
            responseBuild2 = responseBuild.newBuilder().body(exchange.openResponseBody(responseBuild)).build();
        } else {
            responseBuild2 = responseBuild.newBuilder().body(Util.EMPTY_RESPONSE).build();
        }
        if ("close".equalsIgnoreCase(responseBuild2.request().header("Connection")) || "close".equalsIgnoreCase(Response.header$default(responseBuild2, "Connection", null, 2, null))) {
            exchange.noNewExchangesOnConnection();
        }
        if (iCode != 204 || iCode == 205) {
            responseBodyBody = responseBuild2.body();
            if (responseBodyBody != null) {
                contentLength = responseBodyBody.getContentLength();
            } else {
                contentLength = -1;
            }
            if (contentLength > 0) {
                StringBuilder sb3 = new StringBuilder("HTTP ");
                sb3.append(iCode);
                sb3.append(" had non-zero Content-Length: ");
                ResponseBody responseBodyBody4 = responseBuild2.body();
                sb3.append(responseBodyBody4 != null ? Long.valueOf(responseBodyBody4.getContentLength()) : null);
                throw new ProtocolException(sb3.toString());
            }
        }
        return responseBuild2;
    }
}
