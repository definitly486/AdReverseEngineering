package com.explorestack.protobuf;

import java.util.Collections;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-88e60a0b00c44f446761c69dbdea1ba6dba6b1d88516f4344ee4a32f493f3b32 */
/* JADX INFO: loaded from: classes2.dex */
public final class s2 extends t2 {
    public static final s2 d;

    static {
        s2 s2Var = new s2(t2.c);
        Map map = Collections.EMPTY_MAP;
        d = s2Var;
    }
}
